# eumenes-agency

Eumenes が経験から関心・欲求・意図を持ち、発言や行動の機会を選ぶ仕組みを、本体と独立して検証するサブプロジェクト。名前は仮称。

**2026-10-21 時点は設計案。今回の対象は調査と考案まで。実装・fixture 検証・live 評価・製品への接続は未実施。** 実装を依頼された段階で、Eumenes の AGENTS.md に従い設計への合意を確認する。

- [計画と設計](plan.md): 最小循環、状態、処理、段階的な取り込み。
- [既存実装の調査](spec/source-audit.md): Eumenes / Pursuit / Memory / World の再利用先と制約。
- [ホスト接続契約案](spec/host-contract-v1.md): 推論・保存・発話・ツール・忘却の境界。
- [検証計画](spec/verification-plan.md): 固定試験、実モデル評価、遅延・負荷の比較、採用条件。

技術は Bun、TypeScript、SQLite、Zod。Pursuit と同じ独立実験構成にし、取り込み時はビルド済み JS・型宣言を版付き tgz にする。Memory と World は公開 API に接続し、Pursuit は採用した行動を遂行する接続先として後から選べる。

研究対象は、自分の経験・理解・関心と次の行動がつながるかである。発言回数が増えたことだけでは成功としない。合成音声の取得と、実際に聞き手に届いたことも分ける。
