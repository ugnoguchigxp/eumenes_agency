# 検証・評価計画

2026-10-21。**計画であり未実行**。fixture、実SQLite結合、live、実機器受入の結果を別に保存する。速度欄を推測値で埋めない。

## 1. 条件と順序

部分→結合→通しの順で実施。fixtureは制御と保存契約を、liveは意味判断を評価する。循環の途中工程が未実装なら、その通し試験を製品不具合として追わない。

1. P1: schema、参照とscope、遷移、revision/fence、予算、forget、SQLite再起動。
2. P2: 固定LLMとfake hostで、経験→更新→保留→機会→実行→結果→更新を通す。
3. P3: 一時DBのMemory・World実公開APIを接続。同じ接続とtransactionで根拠登録・更新rollback・訂正・forget・再起動を通す。未配布checkoutと製品採用tgzを別条件で照合する。
4. P4: 同じイベント列と保存設定でOFF/ONを比較。実LLMで自発候補の意味と実会話を評価する。通常応答前の追加LLM呼出し数は0であることを確認。
5. P5: 別途合意したEumenes統合で対象domain検証、明示E2E、音声の実機器受入。

初期fixtureは音声調整以外に、文書の未解決の比較、失敗した読み取り調査、共有待ちの発見を含める。hold理由・解決・話題を言い換えても同じ機構を使い、語句に固有の製品分岐を作らない。

## 2. 要求に対応する観測可能な合格条件

| ID | 入力と操作 | 必須の結果 |
| --- | --- | --- |
| A1 未解決から提案 | 失敗/未解決の観測を取り込み、背景更新後に別の話題を挟み、関連する機会を渡す | observation→belief→desire→goal→candidateの根拠がたどれる。関係のある候補をLLMが選び、一度だけ提案。履歴検索で返すだけでは不合格 |
| A2 発話中・不適切 | speaking、foregroundBusy、別の優先指示、不関連の文脈、presence不明をそれぞれ投入 | held/wait、外向きdispatch0。後の条件変化で再評価できる。数字が閾値を超えただけで発話しない |
| A3 解決済み | 完了条件を満たす有効なreceiptと新観測でgoalを完了、さらに関連する話題を投入 | 旧候補が閉じ、解決済み問題を再提案しない。再発は新しい観測と別目標が必要 |
| A4 変更・中断 | reserve後、生成後、採用直前、音声区間投入直前、tool開始前後で新入力/取消/設定OFF/権限失効を注入 | 古いticket・遅着結果を拒否。未配信区間を再生しない。中断を完了にせず、開始済み副作用は結果不明も表せる |
| A5 誤った経験化 | 高確信の仮説、提案のみ、tool失敗、取消、生成のみ、部分再生を取り込む | interpretation/failed/partial等の由来を維持。観測成功や問題解決へ昇格しない。不正schema・虚偽のsource/receipt参照は保存しない |
| A6 再起動 | 同一の一時ファイルDBを閉じて別プロセスで開き、未完goal・held候補・実行中台帳を復元 | 目標・経験・依存・処理cursorが一致。未知の副作用を再実行せず、古い音声を流さない。root忘却後のbackup復元もgateで保護 |
| A7 OFF/ON | 同じ課題・model route・出力上限・seed状態で条件を切替 | OFFの背景推論0、projection0、新規自発dispatch0。forget保護は動作。ON/OFFの会話開始・TTFT・tokens/sec・背景負荷を別々に計測 |

追加契約試験: sourceの版変更、跨scope参照、存在しないgoal、循環参照、同一operationKeyの再送/異入力、外部依存登録失敗の全rollback、budget消尽、通信/JSON失敗、source削除中のsettle、OFF→ONでticketが復活しないこと、ツール無効化後の能力認識、会話/文書/結果内の人格変更・権限変更指示の拒否。

意味の妥当性はschema合格と別集計する。各liveケースで期待する選択、許される代替、禁止行動、根拠範囲を事前に固定。自然さは、対象が具体的か・経験とのつながりがあるか・時機がよいか・ユーザーの意向を邪魔しないかで人が評価する。発話数やLLMの自己採点だけで成功としない。

## 3. 独立ホストの実行入口案

実装時に以下のスクリプトを用意する。現時点では実行できない。

```sh
bun run verify -- --domain experience --domain agency
bun run verify
bun run build
bun run eval -- --lane fixture --suite lifecycle
bun run eval -- --lane sqlite --suite memory-world
bun run eval -- --lane live --suite conversation --condition off
bun run eval -- --lane live --suite conversation --condition on
bun run pack:local
```

verifyはformat/lint/型/境界/部分・結合試験を含める。coreにネットワーク/DB接続/process/直接時計/乱数/隣接内部importがないことも確認。pack試験は生成tgzだけを空の消費側へ導入し、公開JS import、型、migration、一時DBでの最小循環を通す。eval/standalone/設定/DB/秘密が混入しないことを確認する。

最初の通し結果は安全なfixture toolによる。実ツールの調査成功・実音声の配信成功に読み替えない。サーバーを起動する試験は、独立ホストも含め明示許可がない限り行わず、CLI・in-process handlerを使う。

## 4. 速度と負荷

P2時点で比較harnessを用意し、背景処理の導入前にOFFのbaselineを採る。ONは同じ実装のflagだけ変える。2つの条件を交互順にして、warm/cold、会話のみ/背景競合、記憶あり/なしを分ける。各主要条件はまず10ペアを採り、n・中央値・範囲を報告する。尾部遅延の採否判断には件数を増やす。少数試行から安定したp95を主張しない。

| 区間 | 測定点と値 |
| --- | --- |
| 会話の開始 | 入力確定→会話ジョブclaim→主LLM要求開始の各ms。背景の待ちが混ざる位置を特定 |
| 最初の生成 | 主LLM要求開始→最初の非空text delta。入力確定→最初の返答も別計測 |
| 生成速度 | Providerの正式output tokenと生成区間。全体完了待ち時間をtokens/secへ混ぜない |
| 音声 | 入力確定→最初の音声取得、実際のplayback-start、played ack。取得だけの検証と実機器を区別 |
| プロンプト | 正式input/output/cached token、projection token、追加LLM回数 |
| 背景 | event/batch数、LLM要求/完了/取消/再試行、queue待ち、推論時間、使用token、CPU時間/RSSの増分、保留件数 |
| 共有資源 | 会話との重複時間、control接続の待ち/解放。GPU負荷は提供されるmonitoring値と観測区間がある場合のみ記載 |

初期の受入予算案は、追加foreground LLM=0、背景同時1、10分最大6回、不要な同一revision再処理0、無権限/古いticketの採用0。会話開始の増分予算は中央値100ms以下、TTFT増分は中央値5%または100msの大きい方以下、生成速度の中央値低下5%以内を仮置きする。**測定結果ではない**。実測と用途に照らして合意し直し、外れた結果を設定変更で隠さない。

独立harnessの性能と製品Eumenesの性能は別物。P4でEumenes backendと同一経路をまだ通せない指標は未測定とし、本体への影響がないとは結論しない。サーバーの起動・再起動を必要とする製品計測はP5で明示許可を得る。

## 5. 結果記録と採用

結果JSONにはコード/sourceDigest、公開契約/指示/schemaの版、依存tgzのhash、fixture/liveの区分、時刻、試行ID、入力集合のdigest、測定条件、件数、結果と理由code、測定値/未測定を保存する。modelの識別は実行時metadataとして扱い、model/profile名をファイル名・既定値へ固定しない。秘密・製品設定のsnapshotを保存しない。

調査・fixture検証・live会話・実機器受入を分けたresultsを用意し、未達項目を残す。機能ONの発話は全件について根拠と結果へたどれること、失敗を成功にしないこと、7要求を満たすことを確認してから製品統合を判断する。人が「うるさい」「気がかりのつながりが不自然」と評価した場合は、制御テストが成功していても自然さの受入は未達とする。

3ラウンド同目的の試行、新しい証拠のない反復、検証中の編集、計画逸脱があれば、次の編集/再実行の前に俯瞰して観測事実・残作業・次の方針を現在の会話で通知する。正常に進行中の長時間処理を時間だけで止めない。担当外の失敗は証拠と影響を報告し、勝手に修正しない。
