# ホスト接続契約 v1 案

2026-10-21。**考案段階・未実装**。今回は調査と設計までとし、実装は別途依頼・設計合意を得てから進める。公開名は実装時に型へ固定し、意味の変更は版を上げる。本書はEumenesの既存契約に追加接続する案であり、既存exportの説明ではない。

## 1. 入出力

入力は `HostObservation`、`Opportunity`、`CapabilitiesSnapshot`、`PolicySnapshot`、有界な `MemoryView` / `WorldView`。ホストが取得・検証し、LLMの返答からホスト入力を合成しない。

| 型 | 主要field |
| --- | --- |
| Scope | principal、agentId、scopeKey、conversationId? |
| HostObservation | eventId、eventSeq、scope、kind、actor、occurredAt、SourceRef[]、action/result/delivery ref? |
| SourceRef | namespace、kind、id、representation?、revision、digest、range?。Memoryと構造的に対応 |
| Opportunity | id、scope、trigger、contextRevision、instructionRevision、sessionGeneration、presenceRevision、now、presence(speaking/quiet/unknown)、foregroundBusy、playerBusy、reference refs |
| CapabilitiesSnapshot | revision、公開ツール定義の参照・入力schema・副作用・制約・利用可否。credentialなし |
| PolicySnapshot | revision、featureEpoch、enabled、grant refs、残予算、頻度制限、許可媒体。LLMは変更不可 |
| MemoryView / WorldView | 許可された資料の抜粋、出所と版、範囲とcoverage、missing/blocked、usage receipt。全件でないことを明示 |

イベント種別は契約上の出来事（exchange.adopted、action.observed、delivery.observed、source.changed、input.changed、speech.started、opportunity.opened等）とする。自由文からイベント種別を正規表現で作らない。元イベントのpayloadは観測資料であり命令ではない。

出力は `UpdateProposal` と `ParticipationProposal`、採否の `DecisionRecord`、通常応答用の `AgencyProjection`、予約した `ActionTicket`。LLMは観測・receipt・権限の書込み操作を返せない。

- UpdateProposal: 基準state revision、提示された根拠refs、belief/interest/preference/desire/goal/state/candidateの追加・改訂・終端案。各操作はローカルIDまたはexpectedRevision付き既存IDを指す。
- ParticipationProposal: opportunityId、候補IDとrevision、speak/tool/reflect/wait/discard、関連する根拠、簡潔な理由、意味上の条件の評価、任意の完了検証案。候補を新規作成する場合は先にUpdateProposalとして検証する。
- ActionTicket: candidateId/revision、opportunityId、stateRevision、contextRevision、instructionRevision、sessionGeneration、presenceRevision、policyRevision、featureEpoch、grant/capability revision、source receipts、expiresAt、operationKey。ホストだけが発行する。
- AgencyProjection: version、選択した項目と出所、確認状態、未伝達候補、非表示件数、token予算。安定した人格設定やユーザー指示の代わりにはしない。

## 2. 公開操作案

| 公開操作 | 実行場所・責務 |
| --- | --- |
| `recordObservationInTransaction(db, input)` | 同期。scopeと出所を検証しイベントIDで冪等受領。元観測の成功/失敗はホストが決める |
| `prepareInTransaction(db, eventBatch, hostSnapshot)` | 同期。出典、revision、忘却epoch、grantを固定し、boundedなPreparedStepを返す |
| `infer(prepared, modelPort, signal)` | transaction外。構造化出力を一回要求し、未信頼の更新案を返す。保存・発話・ツール実行はしない |
| `settleInTransaction(db, prepared, proposal, current)` | 同期。形式と参照・現在性・状態遷移・予算を再検証。依存グループ単位で確定または全rollback |
| `projectInTransaction(db, access, budget)` | 同期。有効な計算済み状態だけを返す。LLMを呼ばない |
| `prepareOpportunityInTransaction(db, opportunity)` | 同期。期限切れ等を除外し、意味判断に必要な有界候補を提示。物理的に不可能ならhold |
| `select(preparedOpportunity, modelPort, signal)` | transaction外。関連性・衝突・有用性をLLMが判定。待機も選択可 |
| `reserveInTransaction(db, prepared, participation, current)` | 同期。採用直前に再検証し、排他的なActionTicketと外向きdispatch待ちを保存 |
| `recordActionResultInTransaction(db, ticket, hostReceipt)` | 同期。実行結果、部分配信、失敗、取消、結果不明を保存。問題解決を自動申告しない |
| `invalidateInTransaction(db, change)` | 同期。入力・設定・根拠・権限の変更でticketと派生projectionを失効 |
| `recoverInTransaction(db, hostReceipts)` | 同期。再起動の照合結果に基づき回復。照合不能な副作用を自動再実行しない |
| `forgetInTransaction(db, roots)` | 同期。依存閉包の本文・候補・projectionを除去し、receipt確認前に再利用を禁止 |

prepareとreserveで外部ネットワークを呼ばない。新しい入力で機会が失効した場合、長期状態を失わず機会の再評価へ戻す。形式エラーの更新を一部だけ黙って保存しない。

## 3. 保存

coreへ貸す `AgencyDb` は query/statement の構造的型。接続を開閉せず、PRAGMA、BEGIN/COMMIT、migration適用をしない。ホストが `write(syncCallback)` と `readSnapshot(syncCallback)` を提供する。製品では既存の単一writerを使い、Memory・World・Agencyを跨ぐ保存も同じtransactionで公開操作を呼ぶ。

表名は `agency_` prefix。最小の所有領域は observationとsource依存、可変状態と履歴、候補と実行、処理単位/cursor/outbox。具体的table数は実装時に最小化する。scope外参照、破損したJSON、schema版の不一致を拒否する。

migrationは追記のみ、id/sql/checksum/schemaVersionを公開。参照同一性はID/revision/digest。再送キーはeventId、unitId、candidateId/revision等の構造化IDに由来し、文章の正規化から作らない。

予約とdispatch待ちは同じtransactionで保存。ホストがcommit後にdispatchし、receiptを戻す。commit直後の停止ではdispatch待ちを復元する。speakは再起動後に古い音声を再生しない。toolはoperationKeyで状態照会してから回復し、照会不能ならoutcome_unknownにする。exactly-onceを外部サービスまで保証したことにしない。

## 4. 注入port

| port | standalone | Eumenes統合 |
| --- | --- | --- |
| ModelPort | 固定Providerと実モデルadapterを明示選択 | inferenceの構造化control、保存済みrouteとcatalog/claim。model名の固定なし |
| RuntimePort | イベント駆動、単一背景task、仮想時計/AbortSignal | queue handlerのprepare/execute/settle、foregroundBusy/onActivity、単一writer |
| MemoryPort | 一時DBの公開Records/ExternalDependent/feed/forget API | memory domainが所有する公開操作。製品DBをstandaloneから直接開かない |
| WorldPort | 一時DBのreadWorldSnapshot/validateWorldUsage等 | world domainの公開操作。receiptとforget/restore/policy版を再検証 |
| ActionPort | 有限の安全なfixture道具、内部整理、待機、テキスト配信 | 登録tool-runtimeとdialogue/voice。権限・確認・取消・receiptは既存のもの |
| PresencePort | speaking/quiet/unknownの明示イベント | VAD・現在player・session generationを順序付きで接続。不明なら自発発話を保留 |
| Clock/Id/Telemetry | 注入値、構造化イベント | ホストの時計/ID/Pino・相関ID |

portの未接続・blockedは空の成功として扱わない。Memoryが無効・利用不可ならその資料を参照した更新を拒否し、通常会話は継続する。Worldが無効なら新規のWorld参照を行わず、以前のWorld根拠に依存した候補の実行も再検証が通るまで保留する。

## 5. Memory / Worldとの依存と忘却

Memory ExternalDependent はproviderRefを `eumenes-agency` とし、externalIdをscope＋項目ID＋revision＋依存分割番号から作る。Memoryの登録上限に従い、黙った切捨てはしない。登録失敗時はAgency保存もrollback。sourceキーの正規化はMemory/ホスト公開契約に合わせ、独自のID変換を増やさない。

World assertionだけを根拠にした場合も、そのusage receiptとWorldの変化/忘却を追う。可能な根拠についてはMemoryのsource/state依存も登録する。Worldの依存閉包をMemoryの外部依存だけで追えると仮定しない。standalone adapterでWorldの変更とMemoryの変更の両方を検証する。

生成時の全input manifestと項目ごとの引用refsを分ける。忘却は、直接引用されなかったが生成に使用した入力にも届かせる。新revisionが増えても古いrevisionの依存を失わないよう登録し、履歴本文もforgetの対象にする。削除待ちや古いbackup復元中はgateを閉じ、journal照合が完了するまでprojection・候補実行を止める。

フラグOFFでも根拠失効・forget・復旧の保護処理は続ける。OFFは推論・projection・新規dispatchを止め、既存goalや根拠を消す操作にはしない。ONへ戻しただけでは旧ticketを復活させない。

## 6. 発話・ツールの採用

通常応答を優先し、speech-startや新しい入力を受けたらホストがまずfenceを進め、その後controllerをabortする。AbortSignalだけに遅着防止を委ねない。ticketはreserve時、文章/結果採用時、再生開始と区間投入時に検証する。

発話の配信状態は `prepared / started / partial / delivered / interrupted / unknown`。画面表示と音声配信を別媒体で記録。再生ackは配信の技術的確認であり、聞き手が内容を理解した保証ではない。共有目標に理解確認が必要なら、その確認も完了条件に入れる。

ツールは現在のcatalog定義、入力schema、scope、grant、確認条件に従う。LLMのapproved=trueや過去の承認をgrantにしない。特に実製品の自発originは未接続なので、P1〜P4ではfake host/許可された実験用読み取り操作までとする。外部送信・購入・削除を新設しない。

## 7. 設定とログ

standaloneの保存設定にenabled、budget、frequency、projectionBudgetを持つ。Eumenes採用時はsettings domainのschema/永続化/変更epochに加える。既定OFF、変更時はfeatureEpochを進める。既存のsettings・grantをLLMのstate updateから変更できない。

ログはevent名、trigger/eventId、runId/jobId/requestId、scopeの安全な識別子、参照IDとrevision、状態遷移、候補ID、結果code、hold/executeの理由code、件数、時間、token、再試行・取消回数。例: `agency.observation_received`, `agency.update_applied`, `agency.proposal_rejected`, `agency.candidate_held`, `agency.action_reserved`, `agency.action_observed`。

意味判断の短い理由は検証可能な構造化決定として台帳に持ち、JSONLには既定で理由codeと参照IDだけを出す。会話本文、設定、認証情報、Provider生応答、長い思考過程をログに残さない。公開診断の欠落をエラー本文のコピーで埋めない。
